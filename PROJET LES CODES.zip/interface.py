import tkinter as tk
from tkinter import messagebox, simpledialog
from PIL import Image, ImageTk
import os
from dinosaure import *
from ressources import *
from evenements import *
from combat import *
from sauvegarde import sauvegarder_jeu, charger_jeu

# Variables globales
dinos = []
ressources = {}
jour = 1

# Composants graphiques
text_box = None
label_jour = None
root = None

def afficher(message):
    text_box.insert(tk.END, message + '\n')
    text_box.see(tk.END)

def quitter_jeu():
    if messagebox.askyesno("Quitter", "Voulez-vous vraiment quitter le jeu ?"):
        root.destroy()

def afficher_combat_console_to_gui(dino1, dino2, gagnant, perdant, egalite, recompense, spectateurs, gain_spectateurs):
    if egalite:
        afficher(f"⚔️ Match nul entre {dino1['nom']} et {dino2['nom']} ! Les deux sont blessés.")
    else:
        afficher(f"⚔️ {gagnant['nom']} gagne ! {perdant['nom']} est blessé.")
    afficher(f"💰 Récompense : +{recompense} $")
    afficher(f"👥 {spectateurs} spectateurs ont assisté au combat (+{gain_spectateurs} $)")

def interface_acheter_dinosaure():
    global dinos, ressources
    toutes_especes = creer_dinosaures_par_espece()
    especes = list(toutes_especes.keys())

    choix_espece_idx = simpledialog.askinteger(
        "Espèce", 
        "Choisissez une espèce :\n" +
        "\n".join([f"{i+1}. {e}" for i, e in enumerate(especes)]) +
        "\n0. Annuler"
    )

    if choix_espece_idx is None or not (0 <= choix_espece_idx <= len(especes)):
        afficher("Entrée invalide ou annulée.")
        return
    if choix_espece_idx == 0:
        afficher("Achat annulé.")
        return

    espece_choisie = especes[choix_espece_idx - 1]
    dinos_possibles = toutes_especes[espece_choisie]

    choix_dino_idx = simpledialog.askinteger(
        "Dinosaure",
        f"=== Dinosaures disponibles ({espece_choisie}) ===\n" +
        "\n".join([f"{i+1}. {d['nom']} - {d['prix']} $" for i, d in enumerate(dinos_possibles)]) +
        "\n0. Annuler"
    )

    if choix_dino_idx is None or not (0 <= choix_dino_idx <= len(dinos_possibles)):
        afficher("Entrée invalide ou annulée.")
        return
    if choix_dino_idx == 0:
        afficher("Achat annulé.")
        return

    dino = dinos_possibles[choix_dino_idx - 1].copy()
    dino["espece"] = espece_choisie
    if ressources["cagnotte"] >= dino["prix"]:
        ressources["cagnotte"] -= dino["prix"]
        dinos.append(dino)
        afficher(f"✅ {dino['nom']} ajouté au parc !")
    else:
        afficher("❌ Pas assez d'argent.")

def interface_action_simple(action_fonction, message_succes, message_echec=""):
    if action_fonction():
        afficher(message_succes)
    elif message_echec:
        afficher(message_echec)

def interface_afficher_etat():
    etat = f"\n=== ÉTAT DU PARC ===\n"
    for d in dinos:
        etat += f"- {d['nom']} ({d['espece']}) | Faim: {d['faim']} | Soif: {d['soif']} | Santé: {d['sante']}\n"
    etat += f"\nRessources : {ressources}\n"
    afficher(etat)

def interface_combat():
    global dinos
    if len(dinos) < 2:
        afficher("❌ Pas assez de dinosaures pour un combat.")
        return
    import random
    d1, d2 = random.sample(dinos, 2)
    force1 = random.randint(0, 100) + d1['sante']
    force2 = random.randint(0, 100) + d2['sante']

    egalite = force1 == force2
    if force1 > force2:
        d2['sante'] -= 20
        ressources['cagnotte'] += 100
        gagnant, perdant = d1, d2
    elif force2 > force1:
        d1['sante'] -= 20
        ressources['cagnotte'] += 100
        gagnant, perdant = d2, d1
    else:
        d1['sante'] -= 10
        d2['sante'] -= 10
        gagnant = perdant = None

    spectateurs = random.randint(10, 100)
    revenus = spectateurs * 25
    ressources['cagnotte'] += revenus

    afficher_combat_console_to_gui(d1, d2, gagnant, perdant, egalite, 100 if not egalite else 0, spectateurs, revenus)
    dinos[:] = dinosaures_vivants(dinos)

def interface_passer_jour():
    global dinos, jour
    degrader_etat(dinos)
    message = generer_evenement_aleatoire(dinos, ressources)
    afficher(f"🎲 Événement du jour : {message}")
    dinos[:] = dinosaures_vivants(dinos)
    if not dinos:
        messagebox.showinfo("Fin", "💀 Tous vos dinosaures sont morts. Le parc est fermé.")
        root.destroy()
    jour += 1
    label_jour.config(text=f"Jour {jour}")

def interface_soigner():
    ancien_cagnotte = ressources["cagnotte"]
    soigner_dinosaures(dinos, ressources)
    if ressources["cagnotte"] < ancien_cagnotte:
        afficher("🩺 Les dinosaures ont été soignés (-100 $).")
    else:
        afficher("❌ Pas assez d'argent pour soigner les dinosaures.")

def interface_sauvegarder():
    sauvegarder_jeu(dinos, ressources, jour)
    afficher("💾 Partie sauvegardée.")

def interface_charger():
    global dinos, ressources, jour
    dinos_, ressources_, jour_ = charger_jeu()
    if dinos_ is not None:
        dinos[:] = dinos_
        ressources.clear()
        ressources.update(ressources_)
        jour = jour_
        label_jour.config(text=f"Jour {jour}")
        afficher("✅ Partie chargée avec succès.")

def initialiser_boutons(frame):
    actions = [
        ("1. Acheter dinosaure", interface_acheter_dinosaure),
        ("2. Nourrir", lambda: interface_action_simple(lambda: depenser(ressources, "nourriture", 10) and (nourrir_dinosaures(dinos, 20) or True), "🍖 Les dinosaures ont été nourris.", "❌ Pas assez de nourriture.")),
        ("3. Hydrater", lambda: interface_action_simple(lambda: depenser(ressources, "eau", 10) and (hydrater_dinosaures(dinos, 20) or True), "💧 Les dinosaures ont été hydratés.", "❌ Pas assez d'eau.")),
        ("4. Acheter nourriture", lambda: interface_action_simple(lambda: acheter_ressource(ressources, "nourriture", 20, 5), "🛒 Nourriture achetée.", "❌ Pas assez d'argent.")),
        ("5. Acheter eau", lambda: interface_action_simple(lambda: acheter_ressource(ressources, "eau", 20, 3), "🛒 Eau achetée.", "❌ Pas assez d'argent.")),
        ("6. État du parc", interface_afficher_etat),
        ("7. Lancer combat", interface_combat),
        ("8. Jour suivant", interface_passer_jour),
        ("9. Soigner", interface_soigner),
        ("S. Sauvegarder", interface_sauvegarder),
        ("C. Charger partie", interface_charger),
        ("Q. Quitter le jeu", quitter_jeu)
    ]
    for idx, (label, func) in enumerate(actions):
        tk.Button(frame, text=label, command=func).grid(row=1 + idx // 2, column=idx % 2)

def lancer_interface():
    global text_box, label_jour, root, ressources
    root = tk.Tk()
    root.title("Parc à Dinosaures")

    # Image en haut de la fenêtre
    image_path = "C:/Users/W10/Downloads/Photo ptuts.jpeg"
    if os.path.exists(image_path):
        image = Image.open(image_path)
        image = image.resize((800, 200))
        photo = ImageTk.PhotoImage(image)
        image_label = tk.Label(root, image=photo)
        image_label.image = photo  # garder une référence
        image_label.pack()

    frame = tk.Frame(root)
    frame.pack(padx=10, pady=10)

    label_jour = tk.Label(frame, text=f"Jour {jour}")
    label_jour.grid(row=0, column=0, columnspan=2)

    initialiser_boutons(frame)

    text_box = tk.Text(frame, height=20, width=60)
    text_box.grid(row=7, column=0, columnspan=2, pady=10)

    ressources = initialiser_ressources()

    root.mainloop()

if __name__ == "__main__":
    lancer_interface()