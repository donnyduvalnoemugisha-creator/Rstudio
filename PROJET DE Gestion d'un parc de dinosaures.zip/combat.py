import random
import dinosaure

def lancer_combat(dinosaures, ressources):
    if len(dinosaures) < 2:
        print("Pas assez de dinosaures pour un combat.")
        return dinosaures

    combattants = random.sample(dinosaures, 2)
    dino1, dino2 = combattants[0], combattants[1]
    
    print(f"Combat entre {dino1['nom']} ({dino1['espece']}) et {dino2['nom']} ({dino2['espece']}) !")

    force1 = random.randint(0, 100) + dino1['sante']
    force2 = random.randint(0, 100) + dino2['sante']
    if force1 > force2:
     print(f"{dino1['nom']} gagne ! {dino2['nom']} est blessé.")
     dino2['sante'] -= 20
     ressources["cagnotte"] += 100
     print("💰 Récompense : +100 $")
    elif force2 > force1:
     print(f"{dino2['nom']} gagne ! {dino1['nom']} est blessé.")
     dino1['sante'] -= 20
     ressources["cagnotte"] += 100
     print("💰 Récompense : +100 $")
    else:
     print("Match nul ! Les deux dinosaures sont légèrement blessés.")
     dino1['sante'] -= 10
     dino2['sante'] -= 10

     # 🎟️ Revenus des spectateurs
    nb_spectateurs = random.randint(10, 100)
    revenus_spectateurs = nb_spectateurs * 25
    ressources["cagnotte"] += revenus_spectateurs
    print(f"👥 {nb_spectateurs} spectateurs ont assisté au combat (+{revenus_spectateurs} $)")

   
    # Retirer les dinosaures morts
    dinosaures = [d for d in dinosaures if d['sante'] > 0]
    return dinosaures
