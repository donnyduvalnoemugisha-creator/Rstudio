def initialiser_ressources():
    return {"nourriture": 100, "eau": 100, "cagnotte": 1000}

def depenser(ressources, type_ressource, quantite):
    if ressources[type_ressource] >= quantite:
        ressources[type_ressource] -= quantite
        return True
    return False

def gagner_argent(ressources, montant):
    ressources["cagnotte"] += montant

def acheter_ressource(ressources, type_ressource, quantite, prix_unitaire):
    cout = quantite * prix_unitaire
    if ressources["cagnotte"] >= cout:
        ressources["cagnotte"] -= cout
        ressources[type_ressource] += quantite
        return True
    return False
