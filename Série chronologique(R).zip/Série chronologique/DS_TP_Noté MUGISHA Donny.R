#Exercice 1
#1. 
data <- read.csv("C:/Users/User/Downloads/TP noté série chronologique/serie_chronologique_add.csv")
t <- data$t
x <- data$x
#2.
p <- 12
modele_add <- decompose(ts(x, frequency = p), type = "additive")

plot(ts(x, frequency = p), main="Série chronologique + modèle additif")
lines(modele_add$trend + modele_add$seasonal, col="red", lwd=2)
#3.
courbe_modele_additif <- function(t, x, p){
  ts_x <- ts(x, frequency = p)
  decompo <- decompose(ts_x, type="additive")
  
  plot(ts_x, main="Modèle additif ajusté")
  lines(decompo$trend + decompo$seasonal, col="red", lwd=2)
}
#4.
courbe_modele_additif(t[1:60], x[1:60], 12)

#Exercice2
#1.
data2 <- read.csv("C:/Users/User/Downloads/TP noté série chronologique/serie_chronologique_lissage.csv")
x <- data2$x

#Exercice3
#1.
data3 <- read.csv("C:/Users/User/Downloads/TP noté série chronologique/serie_chronologique_lissage.csv")
x <- data3$x
#2.
loess_fit <- loess(x ~ seq_along(x), span = 0.5)
smooth <- predict(loess_fit)
#3.
residus <- x - smooth
MSE <- mean(residus^2)
MSE
#4.
spans <- seq(0.1,1,le=10)#seq(0.1,1,le=10)genere une sequence de nombre,seq c'est la fonction qui genere les sequence,0,1 c'est le point de départ et 1 c'est le point d'arrivée 
MSEs <- rep(NA, length(spans))

for(i in 1:length(spans)){
  fit <- loess(x ~ seq_along(x), span = spans[i])
  pred <- predict(fit)
  MSEs[i] <- mean((x - pred)^2)
}
#5.
plot(spans, MSEs, type="b", main="MSE en fonction du span",
     xlab="Span", ylab="MSE")

#Exercice4
#1.
data <- read.csv("C:/Users/User/Downloads/TP noté série chronologique/serie_chronologique_interpolation_3.csv")
#2.
index_sub <- sample(1:nrow(data),100) #ici c'est à dire qu'on prend 100 points aléatoires dans la série
index_sub <- c(0,sort(index_sub),1)   #On ajoute les extremités 0 et 1
data_sub <- data[index_sub,] #data_sub contient la série sous échantillonée avec seulement certains points connus
#3.
interpolation_lineaire <- function(t, x, new_t){
  n <- length(t)
  new_n <- length(new_t)
  new_x <- rep(NA,new_n)
  
  for(i in 1:new_n){
    index_avant <- rev(which(t <= new_t[i]))[1]
    index_apres <- which(t >= new_t[i])[1]
    
    t1 <- t[index_avant]
    t2 <- t[index_apres]
    x1 <- x[index_avant]
    x2 <- x[index_apres]
    
    if(is.na(index_avant)) new_x[i] <- x2
    else if(is.na(index_apres)) new_x[i] <- x1
    else if(t1 == t2) new_x[i] <- x1
    else new_x[i] <- x1 + (x2-x1) * (new_t[i]-t1)/(t2-t1)
  }
  
  df <- data.frame(t=new_t, x=new_x)
  return(df)
}
#La fonction interpolation_linéaire permet de reconstruire l'ensemble de la série chronologique à partir du sous-echantillon data_sub.
res_interpolation <- interpolation_lineaire(data_sub$t,data_sub$x,data$t)
#Après avoir executer cette ligne on obtient une série interpolée définie sur l'ensemble des temps de la série originale
#4.
plot(data$t, data$x, type="l", col="black", lwd=2, main="Interpolation linéaire")
lines(data$t, data$interpolation, col="red", lwd=2)
#5.
mean(abs(data$x - data$interpolation))
#6.
mean_ecarts <- rep(NA, 1000)
rep(NA,1000)#Crée un vecteur de 1000 cases ,toutes initialisées à NA
#C'est à dire que ce vecteur servira à stocker les 1000 valeurs des écarts moyens obtenus après chaque interpolation linéaire

for(i in 1:1000){
  index_sub <- sample(1:nrow(data), 100)
  index_sub <- c(1, sort(index_sub), nrow(data))
  data_sub <- data[index_sub,]
  
  interp <- interpolation_lineaire(data_sub$t, data_sub$x, data$t)
  mean_ecarts[i] <- mean(abs(data$x - interp$x))
}
#7.
hist(mean_ecarts, breaks=30, main="Distribution des écarts d'interpolation", xlab="Écart moyen")
#Interprétation
#L’histogramme montre la distribution des moyennes des écarts obtenues après 1000 interpolations linéaires sur des sous-échantillonnages aléatoires de la série.