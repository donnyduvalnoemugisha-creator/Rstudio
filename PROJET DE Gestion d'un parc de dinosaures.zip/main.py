import random
from dinosaure import creer_dinosaures_par_espece, nourrir_dinosaures, hydrater_dinosaures, degrader_etat, dinosaures_vivants
from ressources import initialiser_ressources, depenser, gagner_argent, acheter_ressource
from evenements import generer_evenement_aleatoire,soigner_dinosaures
from combat import lancer_combat

def afficher_etat(dinos, ressources):
    print("\n=== ÉTAT DU PARC ===")
    print("Dinosaures dans le parc :")
    for d in dinos:
        print(f"- {d['nom']} ({d['espece']}, {d['regime']}) | Faim: {d['faim']} | Soif: {d['soif']} | Santé: {d['sante']}")
    print("\nRessources :")
    for cle, valeur in ressources.items():
        print(f"{cle.capitalize()} : {valeur}")
    print("=====================")
def acheter_dinosaure(dinos, ressources):
    toutes_especes = creer_dinosaures_par_espece()
    especes = list(toutes_especes.keys())

    print("\n=== Choisissez une espèce ===")
    for i, espece in enumerate(especes):
        print(f"{i+1}. {espece}")
    print("0. Annuler")

    choix_espece = input("Votre choix : ")
    if not choix_espece.isdigit():
        print("Entrée invalide.")
        return

    choix_espece = int(choix_espece)
    if choix_espece == 0:
        print("Achat annulé.")
        return
    elif 1 <= choix_espece <= len(especes):
        espece_choisie = especes[choix_espece - 1]
        dinos_possibles = toutes_especes[espece_choisie]

        print(f"\n=== Dinosaures disponibles ({espece_choisie}) ===")
        for i, d in enumerate(dinos_possibles):
            print(f"{i+1}. {d['nom']} -  {d['prix']} $ ")  # fixe ou variable
        print("0. Annuler")

        choix_dino = input("Choix du dinosaure : ")
        if not choix_dino.isdigit():
            print("Entrée invalide.")
            return

        choix_dino = int(choix_dino)
        if choix_dino == 0:
            print("Achat annulé.")
            return
        elif 1 <= choix_dino <= len(dinos_possibles):
            dino = dinos_possibles[choix_dino - 1].copy()
            dino["espece"] = espece_choisie  # on ajoute l'espèce dans le dino
            prix_dino = dino["prix"]
            if ressources["cagnotte"] >= prix_dino:
             ressources["cagnotte"] -= prix_dino
        dinos.append(dino)
        print(f"✅ {dino['nom']} ajouté au parc !")
    else:
        print("❌ Pas assez d'argent.")


def menu():
    print("\n=== MENU ===")
    print("1.Acheter un dinosaure ")
    print("2. Nourrir les dinosaures")
    print("3. Donner de l'eau aux dinosaures")
    print("4. Acheter de la nourriture")
    print("5. Acheter de l'eau")
    print("6. Afficher l'état du parc")
    print("7. Lancer un combat")
    print("8. Passer au jour suivant")
    print("9.Soigner les dinosaures(dino blessé)")
    print("0. Quitter")

def main():
    dinos = []
    ressources = initialiser_ressources()
    jour = 1

    print("Bienvenue dans le simulateur de parc à dinosaures !")

    while True:
        print(f"\n=== JOUR {jour} ===")
        menu()
        choix = input("Votre choix : ")

        if choix == "1":
            acheter_dinosaure(dinos, ressources)   
        elif choix == "2":
            if depenser(ressources, "nourriture", 10):
                nourrir_dinosaures(dinos, 20)
                print("Les dinosaures ont été nourris.")
            else:
                print("Pas assez de nourriture.")
        elif choix == "3":
            if depenser(ressources, "eau", 10):
                hydrater_dinosaures(dinos, 20)
                print("Les dinosaures ont été hydratés.")
            else:
                print("Pas assez d'eau.")
        elif choix == "4":
            if acheter_ressource(ressources, "nourriture", 20, 5):
                print("Nourriture achetée.")
            else:
                print("Pas assez d'argent.")
        elif choix == "5":
            if acheter_ressource(ressources, "eau", 20, 3):
                print("Eau achetée.")
            else:
                print("Pas assez d'argent.")
        elif choix == "6":
             afficher_etat(dinos, ressources) 
        elif choix == "7":
            dinos = lancer_combat(dinos,ressources)
        elif choix == "8":
            degrader_etat(dinos)
            message = generer_evenement_aleatoire(dinos, ressources)
            print(f"Événement du jour : {message}")
            dinos = dinosaures_vivants(dinos)

            if len(dinos) == 0:
             print("💀 Tous vos dinosaures sont morts. Le parc est fermé.")
             rejouer = input("Souhaitez-vous recommencer une nouvelle partie ? (o/n) : ")
             if rejouer.lower() == "o":
              main()  # relance le jeu
             else:
              print("Merci d'avoir joué !")
              break

            jour += 1

        elif choix == "9":
            soigner_dinosaures(dinos, ressources)

        elif choix == "0":
            print("Merci d'avoir joué ! À bientôt")
            break
        else:
            print("Choix invalide.")

if __name__ == "__main__":
    main()