import random

def creer_dinosaures_par_espece():
    return {
        "Tyrannosaure": [
            {"nom": "Rex", "faim": 0, "soif": 0, "sante": 100, "prix": 650, "regime": "carnivore"},
            {"nom": "King", "faim": 0, "soif": 0, "sante": 100, "prix": 550, "regime": "carnivore"},
            {"nom": "Chomp", "faim": 0, "soif": 0, "sante": 100, "prix": 450, "regime": "carnivore"}
        ],
        "Tricératops": [
            {"nom": "Spike", "faim": 0, "soif": 0, "sante": 100, "prix": 350, "regime": "omnivore"},
            {"nom": "Horny", "faim": 0, "soif": 0, "sante": 100, "prix": 250, "regime": "omnivore"},
            {"nom": "Tank", "faim": 0, "soif": 0, "sante": 100, "prix": 150, "regime": "omnivore"}
        ],
        "Vélociraptor": [
            {"nom": "Blue", "faim": 0, "soif": 0, "sante": 100, "prix": 300, "regime": "herbivore"},
            {"nom": "Echo", "faim": 0, "soif": 0, "sante": 100, "prix": 200, "regime": "herbivore"},
            {"nom": "Delta", "faim": 0, "soif": 0, "sante": 100, "prix": 100, "regime": "herbivore"}
        ]
    }
def nourrir_dinosaures(dinos, quantite):
    for dino in dinos:
        dino["faim"] = max(0, dino["faim"] - quantite)

def hydrater_dinosaures(dinos, quantite):
    for dino in dinos:
        dino["soif"] = max(0, dino["soif"] - quantite)

def degrader_etat(dinos):
    for dino in dinos:
        dino["faim"] += 10
        dino["soif"] += 10
        if dino["faim"] > 50 or dino["soif"] > 50:
            dino["sante"] -= 10


def dinosaures_vivants(dinos):
    return [d for d in dinos if d["sante"] > 0]