import random

def evenement_combat(dinos, ressources):
    if len(dinos) < 2:
        return "Pas assez de dinosaures pour un combat."
    d1, d2 = random.sample(dinos, 2)
    perdant = d1 if d1["sante"] < d2["sante"] else d2
    perdant["sante"] -= 20
    ressources["cagnotte"] += 50
    return f"Combat entre {d1['nom']} et {d2['nom']}, {perdant['nom']} a perdu."

def evenement_epidemie(dinos):
    for dino in dinos:
        dino["sante"] -= 15
    return "Une épidémie a touché le parc ! Tous les dinosaures ont perdu de la santé."

def generer_evenement_aleatoire(dinos, ressources):
    chance = random.randint(1, 100)
    if chance <= 30:
        return evenement_combat(dinos, ressources)
    elif chance <= 50:
        return evenement_epidemie(dinos)
    else:
        return "Aucun événement aujourd'hui."
def soigner_dinosaures(dinos, ressources):
    if ressources["cagnotte"] >= 100:
        ressources["cagnotte"] -= 100
        for d in dinos:
            d["sante"] = min(100, d["sante"] + 20)
        print("🩺 Le dinosaure blessé a été soigné.")
    else:
        print("Pas assez d'argent pour soigner les dinosaures.")
